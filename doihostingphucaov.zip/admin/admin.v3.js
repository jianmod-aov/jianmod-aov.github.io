/* VT ADMIN PRO v2 — hardened dashboard logic */
window.__admRun = 'top-v2';
let CFG = null, TAB = 'overview';
const LS = 'vt-admin-token-v2';
/* Bộ nhớ an toàn: trình duyệt chặn localStorage thì dùng RAM, login vẫn chạy */
let MEM = {};
function lsGet(k) { try { return localStorage.getItem(k); } catch (e) { return (k in MEM) ? MEM[k] : null; } }
function lsSet(k, v) { try { localStorage.setItem(k, v); } catch (e) {} try { MEM[k] = v; } catch (e) {} }
function lsDel(k) { try { localStorage.removeItem(k); } catch (e) {} try { delete MEM[k]; } catch (e) {} }
const $ = id => document.getElementById(id);
const token = () => lsGet(LS);

const SW = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">';
const ICONS = {
  home: SW + '<path d="M3 10.5 12 3l9 7.5"/><path d="M5 9.5V21h14V9.5"/></svg>',
  link: SW + '<path d="M10 13a5 5 0 0 0 7.5.5l3-3a5 5 0 0 0-7-7l-1.7 1.7"/><path d="M14 11a5 5 0 0 0-7.5-.5l-3 3a5 5 0 0 0 7 7l1.7-1.7"/></svg>',
  bell: SW + '<path d="M18 8a6 6 0 1 0-12 0c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.7 21a2 2 0 0 1-3.4 0"/></svg>',
  tag: SW + '<path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/></svg>',
  folder: SW + '<path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/></svg>',
  phone: SW + '<rect x="5" y="2" width="14" height="20" rx="2"/><line x1="12" y1="18" x2="12.01" y2="18"/></svg>',
  image: SW + '<rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="M21 15l-5-5L5 21"/></svg>',
  type: SW + '<path d="M4 7V4h16v3M9 20h6M12 4v16"/></svg>',
  music: SW + '<path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/></svg>',
  sliders: SW + '<line x1="4" y1="21" x2="4" y2="14"/><line x1="4" y1="10" x2="4" y2="3"/><line x1="12" y1="21" x2="12" y2="12"/><line x1="12" y1="8" x2="12" y2="3"/><line x1="20" y1="21" x2="20" y2="16"/><line x1="20" y1="12" x2="20" y2="3"/><line x1="1" y1="14" x2="7" y2="14"/><line x1="9" y1="8" x2="15" y2="8"/><line x1="17" y1="16" x2="23" y2="16"/></svg>',
  user: SW + '<path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>',
  trash: SW + '<path d="M3 6h18M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2m3 0v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"/></svg>',
  plus: SW + '<line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>',
  pulse: SW + '<path d="M22 12h-4l-3 9L9 3l-3 9H2"/></svg>',
  clip: SW + '<path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"/><rect x="8" y="2" width="8" height="4" rx="1"/></svg>',
  grid: SW + '<rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/></svg>',
  play: SW + '<circle cx="12" cy="12" r="10"/><path d="M10 8l6 4-6 4V8z"/></svg>'
};
function H(icn, txt) { return '<span class="h-ic">' + ICONS[icn] + '</span>' + txt; }
const SECTIONS = [
  { sec: 'Tổng quan', items: [['overview', 'home', 'Tổng quan']] },
  { sec: 'Nội dung', items: [['socials', 'link', 'Mạng xã hội'], ['notifs', 'bell', 'Thông báo'], ['linkbox', 'tag', 'LinkBox'], ['groups', 'folder', 'Nhóm'], ['apps', 'phone', 'Apps']] },
  { sec: 'Giao diện', items: [['general', 'image', 'Giao diện chung'], ['ui', 'type', 'Chữ & nút'], ['media', 'music', 'Nhạc & Youtube'], ['theme', 'sliders', 'Màu sắc']] },
  { sec: 'Hệ thống', items: [['account', 'user', 'Tài khoản']] },
];
const ALL_TABS = SECTIONS.flatMap(s => s.items);
window.__admRun = 'consts-ok';
const tabName = t => (ALL_TABS.find(m => m[0] === t) || [])[2] || t;

function esc(s) { return String(s ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;'); }
function toast(m, err) { const t = $('toast'); t.textContent = m; t.className = 'toast show' + (err ? ' err' : ''); clearTimeout(t._h); t._h = setTimeout(() => t.className = 'toast', 6000); }
/* Lưới hứng lỗi toàn cục: bất kỳ lỗi JS nào cũng phải hiện chữ, cấm im lặng */
window.addEventListener('error', e => {
  const msg = 'Lỗi JS: ' + (e.message || e.error);
  const le = $('loginErr'); if (le && !$('loginWrap').hidden) le.textContent = msg;
  toast(msg, 1);
});
window.addEventListener('unhandledrejection', e => {
  const msg = 'Lỗi mạng/bất đồng bộ: ' + ((e.reason && e.reason.message) || e.reason);
  const le = $('loginErr'); if (le && !$('loginWrap').hidden) le.textContent = msg;
  toast(msg, 1);
});
function loading(on, txt) { $('loader').hidden = !on; if (txt) $('loaderTxt').textContent = txt; }
window.__admRun = 'handlers-ok';

/* API wrapper: không bao giờ throw im lặng */
async function api(path, opts) {
  opts = opts || {};
  try {
    const r = await fetch(path, Object.assign({ cache: 'no-store' }, opts));
    let j = null;
    try { j = await r.json(); } catch (e) { j = null; }
    return { http: r.status, ok: r.ok && !!(j && j.ok), data: j, raw: j };
  } catch (e) {
    return { http: 0, ok: false, netErr: true, error: 'Không kết nối được máy chủ (' + e.message + ')' };
  }
}

/* ---------- LOGIN (chống treo, báo lỗi rõ) ---------- */
$('loginForm').onsubmit = async e => {
  e.preventDefault();
  const btn = $('loginBtn'), err = $('loginErr');
  err.textContent = ''; btn.disabled = true; btn.textContent = 'Đang đăng nhập…';
  const u = $('lu').value.trim(), p = $('lp').value.trim();
  if (!u || !p) { err.textContent = 'Nhập đủ tài khoản và mật khẩu.'; btn.disabled = false; btn.textContent = 'Đăng nhập →'; return; }
  const r = await api('/api/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ username: u, password: p }) });
  btn.disabled = false; btn.textContent = 'Đăng nhập →';
  if (r.netErr) { err.textContent = r.error + ' — kiểm tra server có đang chạy đúng port không.'; return; }
  if (r.ok && r.data && r.data.token) { lsSet(LS, r.data.token); boot(); }
  else err.textContent = (r.data && r.data.error) || ('Sai tài khoản hoặc mật khẩu (mã ' + r.http + ').');
};
$('btnLogout').onclick = () => { lsDel(LS); location.reload(); };
$('btnView').onclick = () => window.open('/', '_blank');
$('btnSave').onclick = saveAll;
$('burger').onclick = () => { $('side').classList.add('open'); $('scrim').classList.add('on'); };
$('scrim').onclick = () => { $('side').classList.remove('open'); $('scrim').classList.remove('on'); };
setInterval(() => { const c = $('clock'); if (c) c.textContent = new Date().toLocaleString('vi-VN'); }, 1000);

async function ping() {
  const r = await api('/api/health');
  const pill = $('apiPill');
  if (!pill) return r.ok;
  pill.classList.toggle('bad', !r.ok);
  pill.innerHTML = r.ok ? '<span class="pulse"></span>API Online' : '<span class="pulse"></span>API Offline';
  return r.ok;
}

async function boot() {
  if (!token()) return;
  loading(true, 'Đang tải dữ liệu…');
  const r = await api('/api/admin/data', { headers: { 'X-Admin-Token': token() } });
  loading(false);
  if (!r.ok) { /* token cũ/sai: về login, KHÔNG reload vòng lặp */
    lsDel(LS);
    if (!r.netErr) toast('Phiên cũ hết hạn, mời đăng nhập lại.', 1);
    else toast(r.error, 1);
    return;
  }
  CFG = r.data.data;
  try {
    $('loginWrap').hidden = true; $('app').hidden = false;
    $('meName').textContent = (CFG.settings && CFG.settings.admin_user) || 'admin';
    renderNav(); render(); ping(); setInterval(ping, 60000);
  } catch (e) {
    $('loginWrap').hidden = false; $('app').hidden = true;
    $('loginErr').textContent = 'Đăng nhập OK nhưng dựng dashboard lỗi: ' + (e.message || e);
    toast('Render lỗi: ' + (e.message || e), 1);
  }
}

function renderNav() {
  $('nav').innerHTML = SECTIONS.map(s =>
    '<div class="nav-sec">' + s.sec + '</div>' + s.items.map(m =>
      '<button data-t="' + m[0] + '" class="' + (TAB === m[0] ? 'on' : '') + '"><span class="ic">' + ICONS[m[1]] + '</span>' + m[2] + '</button>'
    ).join('')
  ).join('');
  [...$('nav').querySelectorAll('button')].forEach(b => b.onclick = () => { TAB = b.dataset.t; renderNav(); render(); $('side').classList.remove('open'); $('scrim').classList.remove('on'); });
}

async function saveAll() {
  if (!CFG) return;
  loading(true, 'Đang lưu…');
  const r = await api('/api/admin/save', { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Admin-Token': token() }, body: JSON.stringify(CFG) });
  loading(false);
  if (r.netErr) toast(r.error, 1);
  else if (r.ok) toast('Đã lưu — site public cập nhật ngay ✓');
  else if (r.http === 401) { lsDel(LS); location.reload(); }
  else toast((r.data && r.data.error) || 'Lỗi lưu.', 1);
}

/* ---------- form helpers ---------- */
let FN = {};
window.edit = (el, fn) => { if (FN[fn]) FN[fn](el.value); };
window.vtPrev = el => { const img = el.parentElement.querySelector('img.thumb'); if (img) { img.src = el.value; img.style.display = el.value ? '' : 'none'; } };
function field(label, val, cb, ph) { return '<div class="row"><span class="lbl">' + label + '</span><input value="' + esc(val) + '" placeholder="' + esc(ph || '') + '" oninput="edit(this,\'' + cb + '\')"></div>'; }
function imgField(label, val, cb) {
  return '<div class="row"><span class="lbl">' + label + '</span><div class="imgrow"><img class="thumb" src="' + esc(val || '') + '" ' + (val ? '' : 'style="display:none"') + ' onerror="this.style.display=\'none\'"><input value="' + esc(val || '') + '" placeholder="/uploads/…" oninput="edit(this,\'' + cb + '\');vtPrev(this)"><button type="button" class="btn upbtn" onclick="pickUpload(this)">Tải lên</button><input type="file" hidden accept="image/*" onchange="doUpload(this)"></div></div>';
}
window.pickUpload = btn => { const f = btn.parentElement.querySelector('input[type=file]'); if (f) f.click(); };
window.doUpload = async fi => {
  const f = fi.files && fi.files[0]; if (!f) return;
  if (f.size > 5000000) { toast('Ảnh quá 5MB.', 1); fi.value = ''; return; }
  const row = fi.closest('.imgrow');
  const txt = row ? row.querySelector('input:not([type=file])') : null;
  const img = row ? row.querySelector('img.thumb') : null;
  loading(true, 'Đang tải ảnh…');
  try {
    const fd = new FormData(); fd.append('file', f);
    const r = await fetch('/api/admin/upload', { method: 'POST', headers: { 'X-Admin-Token': token() }, body: fd });
    let j = null; try { j = await r.json(); } catch (e) {}
    loading(false);
    if (r.ok && j && j.ok && j.url) {
      if (txt) { txt.value = j.url; txt.dispatchEvent(new Event('input', { bubbles: true })); }
      if (img) { img.src = j.url; img.style.display = ''; }
      toast('Đã tải ảnh lên ✓ (nhớ bấm Lưu tất cả)');
    } else toast((j && j.error) || ('Tải ảnh thất bại HTTP ' + r.status), 1);
  } catch (e) { loading(false); toast('Lỗi mạng khi tải ảnh.', 1); }
  fi.value = '';
};
function areaField(label, val, cb, ph) { return '<div class="row"><span class="lbl">' + label + '</span><textarea oninput="edit(this,\'' + cb + '\')" placeholder="' + esc(ph || '') + '">' + esc(val) + '</textarea></div>'; }
function confirmDlg(msg) {
  return new Promise(res => {
    $('modalTxt').textContent = msg; $('modalW').hidden = false;
    $('modalYes').onclick = () => { $('modalW').hidden = true; res(true); };
    $('modalNo').onclick = () => { $('modalW').hidden = true; res(false); };
  });
}

/* ---------- render ---------- */
function render() {
  $('pageTitle').textContent = tabName(TAB);
  const p = $('page'); FN = {};
  if (TAB === 'overview') {
    const nA = (CFG.apps || []).length, nG = (CFG.groups || []).length, nS = (CFG.socials || []).length, nN = (CFG.notifs || []).length;
    const rows = (CFG.apps || []).slice(0, 6).map(a => '<tr><td><b>' + esc(a.name) + '</b><br><small style="color:var(--muted)">' + esc(a.desc || '') + '</small></td><td>' + (a.platforms || []).map(x => '<span class="badge">' + esc(x) + '</span>').join('') + '</td><td>' + (a.show_getkey ? 'có' : 'không') + '</td></tr>').join('');
    p.innerHTML =
      '<div class="stats">' +
      '<div class="stat"><span class="sic" style="--tint:#eef0ff;--tintc:#4f46e5">' + ICONS.phone + '</span><span><b>' + nA + '</b><p>Apps</p></span></div>' +
      '<div class="stat"><span class="sic" style="--tint:#e3f5ec;--tintc:#047857">' + ICONS.folder + '</span><span><b>' + nG + '</b><p>Nhóm</p></span></div>' +
      '<div class="stat"><span class="sic" style="--tint:#fff3e2;--tintc:#c26a00">' + ICONS.link + '</span><span><b>' + nS + '</b><p>Socials</p></span></div>' +
      '<div class="stat"><span class="sic" style="--tint:#f3e8ff;--tintc:#7c3aed">' + ICONS.bell + '</span><span><b>' + nN + '</b><p>Thông báo</p></span></div></div>' +
      '<div class="grid2"><div class="panel"><h3>' + H('pulse', 'Kiểm thử API trước bàn giao') + '</h3><div class="body">' +
      '<div class="btnrow"><button class="btn" onclick="testApi(\'/api/health\')">GET /api/health</button>' +
      '<button class="btn" onclick="testApi(\'/api/config\')">GET /api/config</button>' +
      '<button class="btn primary" onclick="window.open(\'/\',\'_blank\')">Mở site public</button></div>' +
      '<div id="apiOut" class="apiout">Bấm nút để test API…</div></div></div>' +
      '<div class="panel"><h3>' + H('clip', 'Checklist bàn giao') + '</h3><div class="body"><div class="hintline">1. Sửa các tab → 2. <b>Lưu tất cả</b> → 3. Test API → 4. Mở site kiểm tra mobile + desktop + bấm thử ảnh preview → 5. Test nhạc phát → 6. Bàn giao.</div></div></div></div>' +
      '<div class="panel"><h3>' + H('phone', 'Apps mới nhất') + '</h3><div class="body"><table class="tbl"><tr><th>Tên</th><th>Nền tảng</th><th>GetKey</th></tr>' + rows + '</table></div></div>';
  }
  else if (TAB === 'general') {
    let i = 0; const S = CFG.settings;
    const bind = k => { const id = 'f' + (i++); FN[id] = v => S[k] = v; return id; };
    const bindWords = () => { const id = 'f' + (i++); FN[id] = v => S.headline_words = v.split(',').map(s => s.trim()).filter(Boolean); return id; };
    p.innerHTML = '<div class="panel"><h3>' + H('image', 'Thông tin site') + '</h3><div class="body">' +
      field('Tiêu đề site', S.site_title, bind('site_title')) +
      field('Mô tả SEO', S.site_desc, bind('site_desc')) +
      field('Dòng Hi', S.iam_text, bind('iam_text')) +
      field('Tên hiển thị', S.profile_name, bind('profile_name')) +
      field('Tiền tố headline', S.headline_prefix, bind('headline_prefix')) +
      field('Từ typing (cách nhau dấu phẩy)', (S.headline_words || []).join(', '), bindWords()) +
      imgField('Avatar', S.avatar_url, bind('avatar_url')) +
      imgField('Khung avatar (trống = tắt)', S.avatar_frame_url || '', bind('avatar_frame_url')) +
      imgField('Ảnh tick xanh', S.verify_img || '/assets/img/verify.png', bind('verify_img')) +
      field('Favicon', S.favicon || '', bind('favicon')) +
      field('Footer', S.footer_text, bind('footer_text')) +
      '<div class="row"><span class="lbl">Tick xanh</span><select onchange="CFG.settings.verify_badge=this.value===\'1\'"><option value="1" ' + (S.verify_badge ? 'selected' : '') + '>Bật</option><option value="0" ' + (!S.verify_badge ? 'selected' : '') + '>Tắt</option></select></div>' +
      '</div></div>';
  }
  else if (TAB === 'ui') {
    let i = 0; const U = CFG.ui || (CFG.ui = {});
    const b = k => { const id = 'u' + (i++); FN[id] = v => U[k] = v; return id; };
    p.innerHTML = '<div class="panel"><h3>' + H('type', 'Chữ & nút trên giao diện') + '</h3><div class="body">' +
      field('Brand topnav', U.nav_brand || '', b('nav_brand')) +
      field('Tiêu đề thông báo', U.notif_title || '', b('notif_title')) +
      field('Text khi không có TB', U.notif_empty || '', b('notif_empty')) +
      field('Ô tìm kiếm', U.search_placeholder || '', b('search_placeholder')) +
      field('Text lọc tất cả', U.filter_all || '', b('filter_all')) +
      field('Nút Tải xuống', U.download_btn || '', b('download_btn')) +
      field('Nút Get Key', U.getkey_btn || '', b('getkey_btn')) +
      field('Nút Subscribe', U.subscribe_btn || '', b('subscribe_btn')) +
      '<div class="hintline">Đổi ở đây → Lưu tất cả → site cập nhật ngay.</div></div></div>';
  }
  else if (TAB === 'socials') p.innerHTML = listEditor('socials', 'link', 'Mạng xã hội', [['label', 'Tên'], ['url', 'Link'], ['icon_url', 'Icon URL (ảnh)']], true);
  else if (TAB === 'notifs') p.innerHTML = listEditor('notifs', 'bell', 'Thông báo', [['title', 'Tiêu đề'], ['content', 'Nội dung'], ['time', 'Thời gian']]);
  else if (TAB === 'linkbox') p.innerHTML = linkboxEditor();
  else if (TAB === 'groups') p.innerHTML = listEditor('groups', 'folder', 'Nhóm App', [['name', 'Tên nhóm']]);
  else if (TAB === 'apps') p.innerHTML = appsEditor();
  else if (TAB === 'media') {
    let i = 0; const M = CFG.music, Y = CFG.youtube;
    const b1 = k => { const id = 'm' + (i++); FN[id] = v => M[k] = v; return id; };
    const b2 = k => { const id = 'm' + (i++); FN[id] = v => Y[k] = v; return id; };
    p.innerHTML = '<div class="panel"><h3>' + H('music', 'Nhạc (mp3 trực tiếp hoặc SoundCloud)') + '</h3><div class="body">' +
      '<div class="row"><span class="lbl">Bật</span><select onchange="CFG.music.enabled=this.value===\'1\'"><option value="1" ' + (M.enabled ? 'selected' : '') + '>Bật</option><option value="0" ' + (!M.enabled ? 'selected' : '') + '>Tắt</option></select></div>' +
      field('Tiêu đề', M.title || '', b1('title')) + field('Ca sĩ', M.artist || '', b1('artist')) +
      field('Audio mp3 (ưu tiên phát trực tiếp)', M.audio_url || '', b1('audio_url')) +
      field('SoundCloud playlist/track URL', M.soundcloud_url || '', b1('soundcloud_url')) +
      '<div class="hintline">Nếu có mp3 → phát trực tiếp. Nếu không → nhúng SoundCloud widget (cần mạng). Nên nhập 1 trong 2.</div></div></div>' +
      '<div class="panel"><h3>' + H('play', 'Youtube') + '</h3><div class="body">' +
      '<div class="row"><span class="lbl">Bật</span><select onchange="CFG.youtube.enabled=this.value===\'1\'"><option value="1" ' + (Y.enabled ? 'selected' : '') + '>Bật</option><option value="0" ' + (!Y.enabled ? 'selected' : '') + '>Tắt</option></select></div>' +
      field('Tên kênh', Y.channel_name || '', b2('channel_name')) + field('Handle', Y.handle || '', b2('handle')) +
      imgField('Avatar kênh', Y.avatar_url || '', b2('avatar_url')) +
      field('Subs', Y.subs || '', b2('subs')) + field('Videos', Y.videos || '', b2('videos')) + field('Link Subscribe', Y.sub_url || '', b2('sub_url')) + '</div></div>';
  }
  else if (TAB === 'theme') {
    let i = 0; const S = CFG.settings;
    const b = k => { const id = 't' + (i++); FN[id] = v => { S[k] = v; paintGrad(); }; return id; };
    p.innerHTML = '<div class="panel"><h3>' + H('sliders', 'Màu sắc & giao diện') + '</h3><div class="body">' +
      '<div class="row"><span class="lbl">Màu chính</span><input type="color" value="' + esc(S.accent || '#4a6cf7') + '" oninput="edit(this,\'' + b('accent') + '\')"></div>' +
      '<div class="row"><span class="lbl">Màu phụ</span><input type="color" value="' + esc(S.accent2 || '#b983ff') + '" oninput="edit(this,\'' + b('accent2') + '\')"></div>' +
      '<div class="row"><span class="lbl">Xem trước</span><div class="gradbar" id="gradBar"></div></div>' +
      '<div class="row"><span class="lbl">Mặc định tối</span><select onchange="CFG.settings.default_dark=this.value===\'1\'"><option value="1" ' + (S.default_dark ? 'selected' : '') + '>Tối</option><option value="0" ' + (!S.default_dark ? 'selected' : '') + '>Sáng</option></select></div>' +
      '</div></div>';
    paintGrad();
  }
  else if (TAB === 'account') {
    p.innerHTML = '<div class="panel"><h3>' + H('user', 'Tài khoản admin') + '</h3><div class="body">' +
      '<div class="row"><span class="lbl">Tài khoản</span><input id="nu" value="' + esc(CFG.settings.admin_user) + '"></div>' +
      '<div class="row"><span class="lbl">Mật khẩu cũ</span><input id="op" type="password" autocomplete="current-password"></div>' +
      '<div class="row"><span class="lbl">Mật khẩu mới</span><input id="np" type="password" autocomplete="new-password"></div>' +
      '<div class="btnrow"><button class="btn primary" onclick="chPass()">Đổi mật khẩu</button></div></div></div>';
  }
}
window.paintGrad = () => { const g = $('gradBar'); if (g && CFG) g.style.background = 'linear-gradient(90deg,' + CFG.settings.accent + ',' + CFG.settings.accent2 + ')'; };

function safeColor(c) { c = String(c || '').trim(); return /^#([0-9a-f]{3}|[0-9a-f]{6})$/i.test(c) ? c : '#4a6cf7'; }
function lbCardHTML(x) {
  return '<a class="vthangios-lb-card" href="' + esc(x.url || '#') + '" target="_blank" rel="noopener">' +
    '<span class="vthangios-lb-ic" style="background:' + safeColor(x.color) + '"><i class="' + esc(x.icon || 'fa-solid fa-link') + '"></i></span>' +
    '<span class="vthangios-lb-tx"><b>' + esc(x.title || 'Tiêu đề card') + '</b><small>' + esc(x.desc || 'Mô tả ngắn') + '</small></span>' +
    '<i class="fa-solid fa-arrow-right vthangios-lb-ar"></i></a>';
}
function linkboxEditor() {
  const arr = CFG.linkboxes || [];
  let h = '<div class="panel"><h3>' + H('tag', 'LinkBox — card CTA') + ' <span class="count">' + arr.length + '</span></h3><div class="body">' +
    '<div class="hintline">Mỗi mục = 1 card trên site (icon màu + tiêu đề + mô tả + mũi tên). Sửa ở đây → <b>Lưu tất cả</b> là site đổi ngay. Chưa có link chắc chắn thì để trống, card vẫn hiện.</div>';
  arr.forEach((it, idx) => {
    h += '<div class="item"><div class="head"><span>#' + (idx + 1) + ' — ' + esc(it.title || 'Box') + '</span><button class="del" onclick="delItem(\'linkboxes\',' + idx + ')">' + ICONS.trash + 'Xóa</button></div>' +
      '<div class="lbprev-wrap"><span class="lbprev-lbl">Xem trước</span><div id="lbPrev' + idx + '">' + lbCardHTML(it) + '</div></div>' +
      '<div class="row"><span class="lbl">Tiêu đề</span><input value="' + esc(it.title || '') + '" placeholder="Shop Mua Key" oninput="CFG.linkboxes[' + idx + '].title=this.value;lbRedraw(' + idx + ')"></div>' +
      '<div class="row"><span class="lbl">Mô tả</span><input value="' + esc(it.desc || '') + '" placeholder="Mua key iOS + Android" oninput="CFG.linkboxes[' + idx + '].desc=this.value;lbRedraw(' + idx + ')"></div>' +
      '<div class="row"><span class="lbl">Icon (class FA)</span><input value="' + esc(it.icon || '') + '" placeholder="fa-solid fa-bag-shopping" oninput="CFG.linkboxes[' + idx + '].icon=this.value;lbRedraw(' + idx + ')"></div>' +
      '<div class="row"><span class="lbl">Màu icon</span><div class="lbcolor"><input type="color" value="' + safeColor(it.color) + '" oninput="CFG.linkboxes[' + idx + '].color=this.value;this.nextElementSibling.value=this.value;lbRedraw(' + idx + ')"><input value="' + esc(it.color || '') + '" placeholder="#16a34a" oninput="CFG.linkboxes[' + idx + '].color=this.value;lbRedraw(' + idx + ')"></div></div>' +
      '<div class="row"><span class="lbl">Link</span><input value="' + esc(it.url || '') + '" placeholder="https://" oninput="CFG.linkboxes[' + idx + '].url=this.value"></div></div>';
  });
  h += '<button class="add" onclick="addItem(\'linkboxes\')">' + ICONS.plus + 'Thêm card</button></div></div>';
  return h;
}
window.lbRedraw = i => { const w = $('lbPrev' + i); if (w) w.innerHTML = lbCardHTML(CFG.linkboxes[i] || {}); };

function listEditor(key, icn, title, cols, withImg) {
  const arr = CFG[key] || [];
  let h = '<div class="panel"><h3>' + H(icn, title) + ' <span class="count">' + arr.length + '</span></h3><div class="body">';
  arr.forEach((it, idx) => {
    h += '<div class="item"><div class="head"><span>#' + (idx + 1) + ' — ' + esc(it.name || it.title || it.label || ('ID ' + it.id)) + '</span><button class="del" onclick="delItem(\'' + key + '\',' + idx + ')">' + ICONS.trash + 'Xóa</button></div>';
    cols.forEach(c => {
      if (withImg && c[0] === 'icon_url') h += imgFieldRow(key, idx, c);
      else h += '<div class="row"><span class="lbl">' + c[1] + '</span><input value="' + esc(it[c[0]] || '') + '" oninput="CFG[\'' + key + '\'][' + idx + '][\'' + c[0] + '\']=this.value"></div>';
    });
    h += '</div>';
  });
  h += '<button class="add" onclick="addItem(\'' + key + '\')">' + ICONS.plus + 'Thêm mới</button></div></div>';
  return h;
}
function imgFieldRow(key, idx, c) {
  const v = CFG[key][idx][c[0]] || '';
  return '<div class="row"><span class="lbl">' + c[1] + '</span><div class="imgrow"><img class="thumb" src="' + esc(v) + '" ' + (v ? '' : 'style="display:none"') + ' onerror="this.style.display=\'none\'"><input value="' + esc(v) + '" oninput="CFG[\'' + key + '\'][' + idx + '][\'' + c[0] + '\']=this.value;this.parentElement.querySelector(\'img\').src=this.value"><button type="button" class="btn upbtn" onclick="pickUpload(this)">Tải lên</button><input type="file" hidden accept="image/*" onchange="doUpload(this)"></div></div>';
}
window.delItem = async (k, i) => { if (await confirmDlg('Xóa mục #' + (i + 1) + ' khỏi ' + k + '?')) { CFG[k].splice(i, 1); render(); saveAll(); } };
window.addItem = k => {
  const id = Date.now() % 100000; const base = { id };
  if (k === 'socials') Object.assign(base, { label: 'Mới', url: 'https://', icon_url: '' });
  if (k === 'notifs') Object.assign(base, { title: 'Thông báo mới', content: 'Nội dung', time: 'Vừa xong' });
  if (k === 'linkboxes') Object.assign(base, { title: 'Shop Mua Key', desc: 'Mua key iOS + Android', icon: 'fa-solid fa-bag-shopping', color: '#16a34a', url: 'https://' });
  if (k === 'groups') Object.assign(base, { name: 'NHÓM MỚI' });
  CFG[k].push(base); render(); saveAll();
};

function appsEditor() {
  const gs = CFG.groups || [];
  let h = '<div class="panel"><h3>' + H('phone', 'Apps') + ' <span class="count">' + (CFG.apps || []).length + '</span></h3><div class="body">';
  (CFG.apps || []).forEach((a, idx) => {
    const plats = a.platforms || [];
    h += '<div class="item"><div class="apphead"><img src="' + esc(a.icon_url || '') + '" onerror="this.style.opacity=.2"><div class="t"><b>#' + (idx + 1) + ' — ' + esc(a.name) + '</b><small>' + esc(a.desc || '') + '</small><br>' + plats.map(x => '<span class="badge">' + esc(x) + '</span>').join('') + '</div><button class="del" onclick="delApp(' + idx + ')">' + ICONS.trash + 'Xóa</button></div>' +
      '<div class="grid2"><div class="row"><span class="lbl">Tên</span><input value="' + esc(a.name) + '" oninput="CFG.apps[' + idx + '].name=this.value"></div>' +
      '<div class="row"><span class="lbl">Nhóm</span><select onchange="CFG.apps[' + idx + '].group_id=+this.value">' + gs.map(g => '<option value="' + g.id + '" ' + (g.id === a.group_id ? 'selected' : '') + '>' + esc(g.name) + '</option>').join('') + '</select></div></div>' +
      '<div class="row"><span class="lbl">Mô tả</span><input value="' + esc(a.desc || '') + '" oninput="CFG.apps[' + idx + '].desc=this.value"></div>' +
      '<div class="row"><span class="lbl">Icon URL</span><div class="imgrow"><img class="thumb" src="' + esc(a.icon_url || '') + '" onerror="this.style.display=\'none\'"><input value="' + esc(a.icon_url || '') + '" oninput="CFG.apps[' + idx + '].icon_url=this.value;this.parentElement.querySelector(\'img\').src=this.value"><button type="button" class="btn upbtn" onclick="pickUpload(this)">Tải lên</button><input type="file" hidden accept="image/*" onchange="doUpload(this)"></div></div>' +
      '<div class="row"><span class="lbl">Banner URL</span><div class="imgrow"><img class="thumb" src="' + esc(a.banner_url || '') + '" onerror="this.style.display=\'none\'"><input value="' + esc(a.banner_url || '') + '" oninput="CFG.apps[' + idx + '].banner_url=this.value;this.parentElement.querySelector(\'img\').src=this.value"><button type="button" class="btn upbtn" onclick="pickUpload(this)">Tải lên</button><input type="file" hidden accept="image/*" onchange="doUpload(this)"></div></div>' +
      '<div class="row"><span class="lbl">Preview (mỗi dòng 1 ảnh)</span><textarea oninput="CFG.apps[' + idx + '].previews=this.value.split(/\\n+/).map(s=>s.trim()).filter(Boolean)">' + esc((a.previews || []).join('\n')) + '</textarea></div>' +
      '<div class="row"><span class="lbl">Nền tảng</span><div class="checks"><label><input type="checkbox" ' + (plats.includes('iOS') ? 'checked' : '') + ' onchange="tglPlat(' + idx + ',\'iOS\',this.checked)">iOS</label><label><input type="checkbox" ' + (plats.includes('Android') ? 'checked' : '') + ' onchange="tglPlat(' + idx + ',\'Android\',this.checked)">Android</label></div></div>' +
      '<div class="row"><span class="lbl">Link tải</span><input value="' + esc(a.download_url || '') + '" oninput="CFG.apps[' + idx + '].download_url=this.value"></div>' +
      '<div class="grid2"><div class="row"><span class="lbl">Hiện GetKey</span><select onchange="CFG.apps[' + idx + '].show_getkey=this.value===\'1\'"><option value="1" ' + (a.show_getkey ? 'selected' : '') + '>Hiện</option><option value="0" ' + (!a.show_getkey ? 'selected' : '') + '>Ẩn</option></select></div>' +
      '<div class="row"><span class="lbl">Link GetKey</span><input value="' + esc(a.getkey_url || '') + '" oninput="CFG.apps[' + idx + '].getkey_url=this.value"></div></div></div>';
  });
  h += '<button class="add" onclick="addApp()">' + ICONS.plus + 'Thêm app</button></div></div>';
  return h;
}
window.delApp = async idx => { if (await confirmDlg('Xóa app "' + (CFG.apps[idx] || {}).name + '"? (tự lưu ngay)')) { CFG.apps.splice(idx, 1); render(); saveAll(); } };
window.addApp = () => { CFG.apps.push({ id: Date.now() % 100000, group_id: (CFG.groups[0] || {}).id || 6, name: 'APP MỚI', desc: 'Cập nhật hôm nay', icon_url: '', banner_url: '', previews: [], platforms: ['iOS'], download_url: 'https://', getkey_url: 'https://', show_getkey: true }); render(); saveAll(); };
window.tglPlat = (idx, pf, on) => { const arr = CFG.apps[idx].platforms || (CFG.apps[idx].platforms = []); const i = arr.indexOf(pf); if (on && i < 0) arr.push(pf); if (!on && i >= 0) arr.splice(i, 1); render(); saveAll(); };

window.testApi = async path => {
  const out = $('apiOut'); out.textContent = 'Đang gọi ' + path + '…';
  const r = await api(path);
  if (r.netErr) { out.textContent = 'LỖI: ' + r.error; toast('API lỗi mạng', 1); return; }
  out.textContent = path + ' → HTTP ' + r.http + '\n' + JSON.stringify(r.data).slice(0, 1200);
  toast(r.ok ? 'API OK: ' + path : 'API trả lỗi HTTP ' + r.http, r.ok ? 0 : 1);
};
window.chPass = async () => {
  const r = await api('/api/admin/change-password', { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Admin-Token': token() }, body: JSON.stringify({ username: $('nu').value, old: $('op').value, new: $('np').value }) });
  if (r.netErr) toast(r.error, 1);
  else if (r.ok) { toast('Đổi mật khẩu xong ✓'); $('op').value = ''; $('np').value = ''; }
  else toast((r.data && r.data.error) || 'Lỗi.', 1);
};

window.__admRun = 'pre-ping';
ping();
if (token()) boot();
else (async () => { /* kiểm tra kết nối ngay trên form login để lộ bệnh mạng */
  window.__admRun = 'srv-checking';
  const el = $('srvInfo');
  const r = await api('/api/health');
  window.__admRun = 'srv-done';
  if (el) el.textContent = r.ok ? ('OK ✓ ' + ((r.data && (r.data.time || r.data.now)) || '')) : ('LỖI ✗ ' + (r.error || ('HTTP ' + r.http)));
})();
