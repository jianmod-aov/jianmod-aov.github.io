<?php
require __DIR__ . '/../_common.php';
if ($_SERVER['REQUEST_METHOD'] !== 'POST') send_json(array('ok' => false, 'error' => 'method'), 405);
require_token();
$b = body_json();
if (!is_array($b) || !$b) send_json(array('ok' => false, 'error' => 'body trống'), 400);
$allowed = array('settings', 'socials', 'notifs', 'linkboxes', 'groups', 'apps', 'music', 'youtube', 'ui');
$cur = load_data();
foreach ($allowed as $k) if (array_key_exists($k, $b)) $cur[$k] = $b[$k];
save_data($cur);
date_default_timezone_set(@date_default_timezone_get());
send_json(array('ok' => true, 'saved_at' => date('Y-m-d H:i:s')));
