<?php
require __DIR__ . '/../_common.php';
if ($_SERVER['REQUEST_METHOD'] !== 'GET') send_json(array('ok' => false, 'error' => 'method'), 405);
require_token();
send_json(array('ok' => true, 'data' => load_data()));
