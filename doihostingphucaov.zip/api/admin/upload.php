<?php
require __DIR__ . '/../_common.php';
if ($_SERVER['REQUEST_METHOD'] !== 'POST') send_json(array('ok' => false, 'error' => 'method'), 405);
require_token();
if (empty($_FILES['file']) || !isset($_FILES['file']['error']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) {
  send_json(array('ok' => false, 'error' => 'Chưa có file hoặc lỗi tải lên'), 400);
}
$f = $_FILES['file'];
if ($f['size'] <= 0 || $f['size'] > 5000000) {
  send_json(array('ok' => false, 'error' => 'File quá lớn (tối đa 5MB)'), 400);
}
$ext = strtolower(pathinfo(isset($f['name']) ? $f['name'] : '', PATHINFO_EXTENSION));
if (!in_array($ext, array('jpg', 'jpeg', 'png', 'webp', 'gif'))) {
  send_json(array('ok' => false, 'error' => 'Chỉ nhận ảnh jpg/png/webp/gif'), 400);
}
$root = dirname(vt_data_file());
$dir = $root . '/uploads/custom';
if (!is_dir($dir)) mkdir($dir, 0755, true);
if (function_exists('random_bytes')) $hex = bin2hex(random_bytes(6));
else $hex = bin2hex(openssl_random_pseudo_bytes(6));
$name = time() . '_' . $hex . '.' . $ext;
if (!move_uploaded_file($f['tmp_name'], $dir . '/' . $name)) {
  send_json(array('ok' => false, 'error' => 'Không lưu được file (kiểm tra quyền uploads/)'), 500);
}
send_json(array('ok' => true, 'url' => '/uploads/custom/' . $name));
