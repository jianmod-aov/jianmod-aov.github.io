<?php
require __DIR__ . '/../_common.php';
if ($_SERVER['REQUEST_METHOD'] !== 'POST') send_json(array('ok' => false, 'error' => 'method'), 405);
require_token();
$b = body_json();
$cur = load_data();
$old = isset($b['old']) ? $b['old'] : '';
$new = isset($b['new']) ? $b['new'] : '';
if ($old !== (isset($cur['settings']['admin_pass']) ? $cur['settings']['admin_pass'] : null)) {
  send_json(array('ok' => false, 'error' => 'Mật khẩu cũ sai'), 400);
}
if (!$new || strlen($new) < 4) {
  send_json(array('ok' => false, 'error' => 'Mật khẩu mới tối thiểu 4 ký tự'), 400);
}
$cur['settings']['admin_pass'] = $new;
if (!empty($b['username'])) $cur['settings']['admin_user'] = $b['username'];
save_data($cur);
send_json(array('ok' => true));
