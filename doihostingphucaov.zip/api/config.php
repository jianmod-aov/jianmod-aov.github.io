<?php
require __DIR__ . '/_common.php';
if ($_SERVER['REQUEST_METHOD'] !== 'GET') send_json(array('ok' => false, 'error' => 'method'), 405);
$d = load_data();
if (isset($d['settings'])) {
  unset($d['settings']['admin_pass'], $d['settings']['admin_user']);
}
send_json(array('ok' => true, 'data' => $d));
