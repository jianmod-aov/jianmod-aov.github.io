<?php
require __DIR__ . '/_common.php';
date_default_timezone_set(@date_default_timezone_get());
send_json(array('ok' => true, 'time' => date('Y-m-d H:i:s')));
