<?php
/* Dùng chung cho mọi API: CORS, JSON, data.json, token (file, tương đương bản Python). */
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET,POST,PUT,DELETE,OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, X-Admin-Token');
if (isset($_SERVER['REQUEST_METHOD']) && $_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
  http_response_code(204);
  exit;
}

function vt_data_file() {
  $d = __DIR__;
  for ($i = 0; $i < 4; $i++) {
    if (is_file($d . '/data.json')) return $d . '/data.json';
    $d = dirname($d);
  }
  return __DIR__ . '/../data.json';
}
function vt_tokens_file() { return dirname(__FILE__) . '/tokens.json'; }

function load_data() {
  $raw = @file_get_contents(vt_data_file());
  $d = $raw ? json_decode($raw, true) : null;
  return is_array($d) ? $d : array();
}
function save_data($d) {
  $file = vt_data_file();
  $tmp = $file . '.tmp';
  file_put_contents($tmp, json_encode($d, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT), LOCK_EX);
  rename($tmp, $file);
}
function send_json($obj, $code = 200) {
  http_response_code($code);
  header('Content-Type: application/json; charset=utf-8');
  echo json_encode($obj, JSON_UNESCAPED_UNICODE);
  exit;
}
function body_json() {
  $raw = file_get_contents('php://input');
  if (!$raw || strlen($raw) > 2000000) return array();
  $j = json_decode($raw, true);
  return is_array($j) ? $j : array();
}
function load_tokens() {
  $raw = @file_get_contents(vt_tokens_file());
  $t = $raw ? json_decode($raw, true) : null;
  if (!is_array($t)) $t = array();
  $now = time();
  foreach ($t as $k => $exp) if ($exp < $now) unset($t[$k]);
  return $t;
}
function store_tokens($t) {
  file_put_contents(vt_tokens_file(), json_encode($t, JSON_UNESCAPED_UNICODE), LOCK_EX);
}
function vt_random_token() {
  if (function_exists('random_bytes')) return 'vt_' . bin2hex(random_bytes(16));
  return 'vt_' . bin2hex(openssl_random_pseudo_bytes(16));
}
function make_token($user) {
  $t = load_tokens();
  $tok = vt_random_token();
  $t[$tok] = time() + 12 * 3600;
  store_tokens($t);
  return $tok;
}
function check_token() {
  $tok = null;
  if (isset($_SERVER['HTTP_X_ADMIN_TOKEN'])) $tok = $_SERVER['HTTP_X_ADMIN_TOKEN'];
  if (!$tok && function_exists('getallheaders')) {
    foreach (getallheaders() as $k => $v) {
      if (strtolower($k) === 'x-admin-token') { $tok = $v; break; }
    }
  }
  if (!$tok) return false;
  $t = load_tokens();
  if (!isset($t[$tok]) || $t[$tok] < time()) {
    if (isset($t[$tok])) { unset($t[$tok]); store_tokens($t); }
    return false;
  }
  return true;
}
function require_token() {
  if (!check_token()) send_json(array('ok' => false, 'error' => 'unauthorized'), 401);
}
