<?php
require __DIR__ . '/_common.php';
if ($_SERVER['REQUEST_METHOD'] !== 'POST') send_json(array('ok' => false, 'error' => 'method'), 405);
$b = body_json();
$d = load_data();
$st = isset($d['settings']) ? $d['settings'] : array();
$u = isset($b['username']) ? $b['username'] : '';
$p = isset($b['password']) ? $b['password'] : '';
if ($u !== '' && $u === (isset($st['admin_user']) ? $st['admin_user'] : null) && $p === (isset($st['admin_pass']) ? $st['admin_pass'] : null)) {
  send_json(array('ok' => true, 'token' => make_token($u)));
}
send_json(array('ok' => false, 'error' => 'Sai tài khoản hoặc mật khẩu'), 401);
